﻿namespace VO2_Max
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpSocialNetworks = new System.Windows.Forms.GroupBox();
            this.picInsta = new System.Windows.Forms.PictureBox();
            this.picFB = new System.Windows.Forms.PictureBox();
            this.picTwitter = new System.Windows.Forms.PictureBox();
            this.lblStep1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labelMatchPass = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtReEnterPassword = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSignUp = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkedListBoxResidence = new System.Windows.Forms.CheckedListBox();
            this.textBoxSport = new System.Windows.Forms.TextBox();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.textBoxStudent = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.linkLabelAbout = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.grpSocialNetworks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInsta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTwitter)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpSocialNetworks
            // 
            this.grpSocialNetworks.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grpSocialNetworks.Controls.Add(this.picInsta);
            this.grpSocialNetworks.Controls.Add(this.picFB);
            this.grpSocialNetworks.Controls.Add(this.picTwitter);
            this.grpSocialNetworks.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.grpSocialNetworks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grpSocialNetworks.Location = new System.Drawing.Point(1004, 16);
            this.grpSocialNetworks.Name = "grpSocialNetworks";
            this.grpSocialNetworks.Size = new System.Drawing.Size(200, 75);
            this.grpSocialNetworks.TabIndex = 28;
            this.grpSocialNetworks.TabStop = false;
            this.grpSocialNetworks.Text = "Follow us:";
            // 
            // picInsta
            // 
            this.picInsta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picInsta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picInsta.Location = new System.Drawing.Point(131, 19);
            this.picInsta.Name = "picInsta";
            this.picInsta.Size = new System.Drawing.Size(52, 50);
            this.picInsta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picInsta.TabIndex = 9;
            this.picInsta.TabStop = false;
            // 
            // picFB
            // 
            this.picFB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picFB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picFB.Location = new System.Drawing.Point(6, 19);
            this.picFB.Name = "picFB";
            this.picFB.Size = new System.Drawing.Size(50, 50);
            this.picFB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFB.TabIndex = 7;
            this.picFB.TabStop = false;
            // 
            // picTwitter
            // 
            this.picTwitter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picTwitter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picTwitter.Location = new System.Drawing.Point(72, 19);
            this.picTwitter.Name = "picTwitter";
            this.picTwitter.Size = new System.Drawing.Size(53, 50);
            this.picTwitter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTwitter.TabIndex = 8;
            this.picTwitter.TabStop = false;
            // 
            // lblStep1
            // 
            this.lblStep1.AutoSize = true;
            this.lblStep1.Font = new System.Drawing.Font("Impact", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStep1.Location = new System.Drawing.Point(245, 137);
            this.lblStep1.Name = "lblStep1";
            this.lblStep1.Size = new System.Drawing.Size(65, 26);
            this.lblStep1.TabIndex = 26;
            this.lblStep1.Text = "STEP 1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelMatchPass);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtReEnterPassword);
            this.groupBox2.Controls.Add(this.txtPassword);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(793, 421);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(420, 129);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Create password";
            // 
            // labelMatchPass
            // 
            this.labelMatchPass.AutoSize = true;
            this.labelMatchPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMatchPass.ForeColor = System.Drawing.Color.Black;
            this.labelMatchPass.Location = new System.Drawing.Point(125, 103);
            this.labelMatchPass.Name = "labelMatchPass";
            this.labelMatchPass.Size = new System.Drawing.Size(196, 24);
            this.labelMatchPass.TabIndex = 21;
            this.labelMatchPass.Text = "Does password match";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 14);
            this.label3.TabIndex = 20;
            this.label3.Text = "Re-enter password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 14);
            this.label2.TabIndex = 19;
            this.label2.Text = "new Password:";
            // 
            // txtReEnterPassword
            // 
            this.txtReEnterPassword.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtReEnterPassword.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReEnterPassword.Location = new System.Drawing.Point(117, 70);
            this.txtReEnterPassword.Multiline = true;
            this.txtReEnterPassword.Name = "txtReEnterPassword";
            this.txtReEnterPassword.Size = new System.Drawing.Size(260, 34);
            this.txtReEnterPassword.TabIndex = 18;
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtPassword.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(117, 30);
            this.txtPassword.Multiline = true;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(260, 34);
            this.txtPassword.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Impact", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(231, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 26);
            this.label1.TabIndex = 17;
            this.label1.Text = "STEP 2";
            // 
            // btnSignUp
            // 
            this.btnSignUp.BackColor = System.Drawing.Color.Teal;
            this.btnSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignUp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSignUp.Location = new System.Drawing.Point(877, 571);
            this.btnSignUp.Name = "btnSignUp";
            this.btnSignUp.Size = new System.Drawing.Size(283, 47);
            this.btnSignUp.TabIndex = 18;
            this.btnSignUp.Text = "SIGN UP";
            this.btnSignUp.UseVisualStyleBackColor = false;
            this.btnSignUp.Click += new System.EventHandler(this.btnSignUp_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkedListBoxResidence);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(35, 460);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(545, 158);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Residence";
            // 
            // checkedListBoxResidence
            // 
            this.checkedListBoxResidence.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBoxResidence.FormattingEnabled = true;
            this.checkedListBoxResidence.Items.AddRange(new object[] {
            "Horizon",
            "Kumba",
            "Acacia",
            "Acadamia",
            "Jasmyn",
            "LongFellow",
            "Thutuka",
            "Faranani",
            "Other"});
            this.checkedListBoxResidence.Location = new System.Drawing.Point(18, 37);
            this.checkedListBoxResidence.Name = "checkedListBoxResidence";
            this.checkedListBoxResidence.Size = new System.Drawing.Size(497, 80);
            this.checkedListBoxResidence.TabIndex = 0;
            // 
            // textBoxSport
            // 
            this.textBoxSport.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBoxSport.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSport.Location = new System.Drawing.Point(243, 341);
            this.textBoxSport.Multiline = true;
            this.textBoxSport.Name = "textBoxSport";
            this.textBoxSport.Size = new System.Drawing.Size(297, 44);
            this.textBoxSport.TabIndex = 23;
            // 
            // textBoxId
            // 
            this.textBoxId.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBoxId.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxId.Location = new System.Drawing.Point(243, 289);
            this.textBoxId.Multiline = true;
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(297, 46);
            this.textBoxId.TabIndex = 22;
            // 
            // textBoxStudent
            // 
            this.textBoxStudent.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBoxStudent.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxStudent.Location = new System.Drawing.Point(243, 242);
            this.textBoxStudent.Multiline = true;
            this.textBoxStudent.Name = "textBoxStudent";
            this.textBoxStudent.Size = new System.Drawing.Size(297, 41);
            this.textBoxStudent.TabIndex = 21;
            // 
            // textBoxName
            // 
            this.textBoxName.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBoxName.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxName.Location = new System.Drawing.Point(243, 192);
            this.textBoxName.Multiline = true;
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(297, 44);
            this.textBoxName.TabIndex = 20;
            // 
            // linkLabelAbout
            // 
            this.linkLabelAbout.ActiveLinkColor = System.Drawing.Color.Maroon;
            this.linkLabelAbout.AutoSize = true;
            this.linkLabelAbout.BackColor = System.Drawing.Color.Teal;
            this.linkLabelAbout.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelAbout.LinkColor = System.Drawing.Color.Maroon;
            this.linkLabelAbout.Location = new System.Drawing.Point(619, 648);
            this.linkLabelAbout.Name = "linkLabelAbout";
            this.linkLabelAbout.Size = new System.Drawing.Size(94, 24);
            this.linkLabelAbout.TabIndex = 19;
            this.linkLabelAbout.TabStop = true;
            this.linkLabelAbout.Text = "Click here";
            this.linkLabelAbout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelAbout_LinkClicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(40, 295);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 24);
            this.label4.TabIndex = 29;
            this.label4.Text = "ID Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(31, 388);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(392, 73);
            this.label5.TabIndex = 30;
            this.label5.Text = "                    ";
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::VO2_Max.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1239, 690);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.grpSocialNetworks);
            this.Controls.Add(this.lblStep1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnSignUp);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBoxSport);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.textBoxStudent);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.linkLabelAbout);
            this.Name = "SignUp";
            this.Text = "SignUp";
            this.grpSocialNetworks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picInsta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTwitter)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpSocialNetworks;
        private System.Windows.Forms.PictureBox picInsta;
        private System.Windows.Forms.PictureBox picFB;
        private System.Windows.Forms.PictureBox picTwitter;
        private System.Windows.Forms.Label lblStep1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtReEnterPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSignUp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckedListBox checkedListBoxResidence;
        private System.Windows.Forms.TextBox textBoxSport;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.TextBox textBoxStudent;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.LinkLabel linkLabelAbout;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelMatchPass;
    }
}