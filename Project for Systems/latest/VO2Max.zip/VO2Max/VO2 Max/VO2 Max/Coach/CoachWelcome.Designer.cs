﻿namespace VO2_Max.Coach
{
    partial class CoachWelcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabelP2 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP3 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP4 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP5 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP6 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP7 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP8 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP9 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP10 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP11 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP12 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP13 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP14 = new System.Windows.Forms.LinkLabel();
            this.linkLabelP1 = new System.Windows.Forms.LinkLabel();
            this.listBoxData = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelTeamName = new System.Windows.Forms.Label();
            this.groupBoxSort = new System.Windows.Forms.GroupBox();
            this.radioButtonVo2max = new System.Windows.Forms.RadioButton();
            this.radioButtonSpeed = new System.Windows.Forms.RadioButton();
            this.radioButtonBMI = new System.Windows.Forms.RadioButton();
            this.radioButtonHeartRate = new System.Windows.Forms.RadioButton();
            this.listBoxSchedule = new System.Windows.Forms.ListBox();
            this.labelSchedule = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBoxSort.SuspendLayout();
            this.SuspendLayout();
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(36, 46);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(109, 20);
            this.label.TabIndex = 0;
            this.label.Text = "Coach name";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.linkLabelP2);
            this.panel1.Controls.Add(this.linkLabelP3);
            this.panel1.Controls.Add(this.linkLabelP4);
            this.panel1.Controls.Add(this.linkLabelP5);
            this.panel1.Controls.Add(this.linkLabelP6);
            this.panel1.Controls.Add(this.linkLabelP7);
            this.panel1.Controls.Add(this.linkLabelP8);
            this.panel1.Controls.Add(this.linkLabelP9);
            this.panel1.Controls.Add(this.linkLabelP10);
            this.panel1.Controls.Add(this.linkLabelP11);
            this.panel1.Controls.Add(this.linkLabelP12);
            this.panel1.Controls.Add(this.linkLabelP13);
            this.panel1.Controls.Add(this.linkLabelP14);
            this.panel1.Controls.Add(this.linkLabelP1);
            this.panel1.Controls.Add(this.listBoxData);
            this.panel1.Location = new System.Drawing.Point(40, 92);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(288, 545);
            this.panel1.TabIndex = 1;
            // 
            // linkLabelP2
            // 
            this.linkLabelP2.AutoSize = true;
            this.linkLabelP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP2.Location = new System.Drawing.Point(4, 53);
            this.linkLabelP2.Name = "linkLabelP2";
            this.linkLabelP2.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP2.TabIndex = 14;
            this.linkLabelP2.TabStop = true;
            this.linkLabelP2.Text = "Position 2";
            // 
            // linkLabelP3
            // 
            this.linkLabelP3.AutoSize = true;
            this.linkLabelP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP3.Location = new System.Drawing.Point(4, 85);
            this.linkLabelP3.Name = "linkLabelP3";
            this.linkLabelP3.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP3.TabIndex = 13;
            this.linkLabelP3.TabStop = true;
            this.linkLabelP3.Text = "Position 3";
            // 
            // linkLabelP4
            // 
            this.linkLabelP4.AutoSize = true;
            this.linkLabelP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP4.Location = new System.Drawing.Point(4, 119);
            this.linkLabelP4.Name = "linkLabelP4";
            this.linkLabelP4.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP4.TabIndex = 12;
            this.linkLabelP4.TabStop = true;
            this.linkLabelP4.Text = "Position 4";
            // 
            // linkLabelP5
            // 
            this.linkLabelP5.AutoSize = true;
            this.linkLabelP5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP5.Location = new System.Drawing.Point(4, 150);
            this.linkLabelP5.Name = "linkLabelP5";
            this.linkLabelP5.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP5.TabIndex = 11;
            this.linkLabelP5.TabStop = true;
            this.linkLabelP5.Text = "Position 5";
            // 
            // linkLabelP6
            // 
            this.linkLabelP6.AutoSize = true;
            this.linkLabelP6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP6.Location = new System.Drawing.Point(4, 188);
            this.linkLabelP6.Name = "linkLabelP6";
            this.linkLabelP6.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP6.TabIndex = 10;
            this.linkLabelP6.TabStop = true;
            this.linkLabelP6.Text = "Position 6";
            // 
            // linkLabelP7
            // 
            this.linkLabelP7.AutoSize = true;
            this.linkLabelP7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP7.Location = new System.Drawing.Point(4, 227);
            this.linkLabelP7.Name = "linkLabelP7";
            this.linkLabelP7.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP7.TabIndex = 9;
            this.linkLabelP7.TabStop = true;
            this.linkLabelP7.Text = "Position 7";
            // 
            // linkLabelP8
            // 
            this.linkLabelP8.AutoSize = true;
            this.linkLabelP8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP8.Location = new System.Drawing.Point(4, 264);
            this.linkLabelP8.Name = "linkLabelP8";
            this.linkLabelP8.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP8.TabIndex = 8;
            this.linkLabelP8.TabStop = true;
            this.linkLabelP8.Text = "Position 8";
            // 
            // linkLabelP9
            // 
            this.linkLabelP9.AutoSize = true;
            this.linkLabelP9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP9.Location = new System.Drawing.Point(4, 296);
            this.linkLabelP9.Name = "linkLabelP9";
            this.linkLabelP9.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP9.TabIndex = 7;
            this.linkLabelP9.TabStop = true;
            this.linkLabelP9.Text = "Position 9";
            // 
            // linkLabelP10
            // 
            this.linkLabelP10.AutoSize = true;
            this.linkLabelP10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP10.Location = new System.Drawing.Point(4, 336);
            this.linkLabelP10.Name = "linkLabelP10";
            this.linkLabelP10.Size = new System.Drawing.Size(73, 16);
            this.linkLabelP10.TabIndex = 6;
            this.linkLabelP10.TabStop = true;
            this.linkLabelP10.Text = "Position 10";
            // 
            // linkLabelP11
            // 
            this.linkLabelP11.AutoSize = true;
            this.linkLabelP11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP11.Location = new System.Drawing.Point(4, 373);
            this.linkLabelP11.Name = "linkLabelP11";
            this.linkLabelP11.Size = new System.Drawing.Size(73, 16);
            this.linkLabelP11.TabIndex = 5;
            this.linkLabelP11.TabStop = true;
            this.linkLabelP11.Text = "Position 11";
            // 
            // linkLabelP12
            // 
            this.linkLabelP12.AutoSize = true;
            this.linkLabelP12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP12.Location = new System.Drawing.Point(3, 410);
            this.linkLabelP12.Name = "linkLabelP12";
            this.linkLabelP12.Size = new System.Drawing.Size(73, 16);
            this.linkLabelP12.TabIndex = 4;
            this.linkLabelP12.TabStop = true;
            this.linkLabelP12.Text = "Position 12";
            // 
            // linkLabelP13
            // 
            this.linkLabelP13.AutoSize = true;
            this.linkLabelP13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP13.Location = new System.Drawing.Point(4, 452);
            this.linkLabelP13.Name = "linkLabelP13";
            this.linkLabelP13.Size = new System.Drawing.Size(73, 16);
            this.linkLabelP13.TabIndex = 3;
            this.linkLabelP13.TabStop = true;
            this.linkLabelP13.Text = "Position 13";
            // 
            // linkLabelP14
            // 
            this.linkLabelP14.AutoSize = true;
            this.linkLabelP14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP14.Location = new System.Drawing.Point(4, 498);
            this.linkLabelP14.Name = "linkLabelP14";
            this.linkLabelP14.Size = new System.Drawing.Size(73, 16);
            this.linkLabelP14.TabIndex = 2;
            this.linkLabelP14.TabStop = true;
            this.linkLabelP14.Text = "Position 14";
            // 
            // linkLabelP1
            // 
            this.linkLabelP1.AutoSize = true;
            this.linkLabelP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelP1.Location = new System.Drawing.Point(4, 21);
            this.linkLabelP1.Name = "linkLabelP1";
            this.linkLabelP1.Size = new System.Drawing.Size(66, 16);
            this.linkLabelP1.TabIndex = 1;
            this.linkLabelP1.TabStop = true;
            this.linkLabelP1.Text = "Position 1";
            // 
            // listBoxData
            // 
            this.listBoxData.FormattingEnabled = true;
            this.listBoxData.Location = new System.Drawing.Point(154, 0);
            this.listBoxData.Name = "listBoxData";
            this.listBoxData.Size = new System.Drawing.Size(134, 550);
            this.listBoxData.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox1.Location = new System.Drawing.Point(369, 196);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(372, 370);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // labelTeamName
            // 
            this.labelTeamName.AutoSize = true;
            this.labelTeamName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTeamName.Location = new System.Drawing.Point(492, 173);
            this.labelTeamName.Name = "labelTeamName";
            this.labelTeamName.Size = new System.Drawing.Size(102, 20);
            this.labelTeamName.TabIndex = 3;
            this.labelTeamName.Text = "Team name";
            // 
            // groupBoxSort
            // 
            this.groupBoxSort.Controls.Add(this.radioButtonVo2max);
            this.groupBoxSort.Controls.Add(this.radioButtonSpeed);
            this.groupBoxSort.Controls.Add(this.radioButtonBMI);
            this.groupBoxSort.Controls.Add(this.radioButtonHeartRate);
            this.groupBoxSort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxSort.Location = new System.Drawing.Point(805, 92);
            this.groupBoxSort.Name = "groupBoxSort";
            this.groupBoxSort.Size = new System.Drawing.Size(200, 178);
            this.groupBoxSort.TabIndex = 4;
            this.groupBoxSort.TabStop = false;
            this.groupBoxSort.Text = "Sort by";
            // 
            // radioButtonVo2max
            // 
            this.radioButtonVo2max.AutoSize = true;
            this.radioButtonVo2max.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonVo2max.Location = new System.Drawing.Point(24, 135);
            this.radioButtonVo2max.Name = "radioButtonVo2max";
            this.radioButtonVo2max.Size = new System.Drawing.Size(78, 20);
            this.radioButtonVo2max.TabIndex = 4;
            this.radioButtonVo2max.TabStop = true;
            this.radioButtonVo2max.Text = "Vo2 Max";
            this.radioButtonVo2max.UseVisualStyleBackColor = true;
            // 
            // radioButtonSpeed
            // 
            this.radioButtonSpeed.AutoSize = true;
            this.radioButtonSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSpeed.Location = new System.Drawing.Point(24, 100);
            this.radioButtonSpeed.Name = "radioButtonSpeed";
            this.radioButtonSpeed.Size = new System.Drawing.Size(67, 20);
            this.radioButtonSpeed.TabIndex = 2;
            this.radioButtonSpeed.TabStop = true;
            this.radioButtonSpeed.Text = "Speed";
            this.radioButtonSpeed.UseVisualStyleBackColor = true;
            // 
            // radioButtonBMI
            // 
            this.radioButtonBMI.AutoSize = true;
            this.radioButtonBMI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonBMI.Location = new System.Drawing.Point(24, 62);
            this.radioButtonBMI.Name = "radioButtonBMI";
            this.radioButtonBMI.Size = new System.Drawing.Size(129, 20);
            this.radioButtonBMI.TabIndex = 1;
            this.radioButtonBMI.TabStop = true;
            this.radioButtonBMI.Text = "Body Mass Index";
            this.radioButtonBMI.UseVisualStyleBackColor = true;
            // 
            // radioButtonHeartRate
            // 
            this.radioButtonHeartRate.AutoSize = true;
            this.radioButtonHeartRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonHeartRate.Location = new System.Drawing.Point(24, 21);
            this.radioButtonHeartRate.Name = "radioButtonHeartRate";
            this.radioButtonHeartRate.Size = new System.Drawing.Size(91, 20);
            this.radioButtonHeartRate.TabIndex = 0;
            this.radioButtonHeartRate.TabStop = true;
            this.radioButtonHeartRate.Text = "Heart Rate";
            this.radioButtonHeartRate.UseVisualStyleBackColor = true;
            // 
            // listBoxSchedule
            // 
            this.listBoxSchedule.FormattingEnabled = true;
            this.listBoxSchedule.Location = new System.Drawing.Point(805, 388);
            this.listBoxSchedule.Name = "listBoxSchedule";
            this.listBoxSchedule.Size = new System.Drawing.Size(200, 238);
            this.listBoxSchedule.TabIndex = 5;
            // 
            // labelSchedule
            // 
            this.labelSchedule.AutoSize = true;
            this.labelSchedule.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSchedule.Location = new System.Drawing.Point(805, 365);
            this.labelSchedule.Name = "labelSchedule";
            this.labelSchedule.Size = new System.Drawing.Size(125, 20);
            this.labelSchedule.TabIndex = 6;
            this.labelSchedule.Text = "Gym Schedule";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(922, 637);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(96, 23);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // CoachWelcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 672);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.labelSchedule);
            this.Controls.Add(this.listBoxSchedule);
            this.Controls.Add(this.groupBoxSort);
            this.Controls.Add(this.labelTeamName);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label);
            this.MaximumSize = new System.Drawing.Size(1063, 711);
            this.MinimumSize = new System.Drawing.Size(1063, 711);
            this.Name = "CoachWelcome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CoachWelcome";
            this.Load += new System.EventHandler(this.CoachWelcome_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBoxSort.ResumeLayout(false);
            this.groupBoxSort.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel linkLabelP2;
        private System.Windows.Forms.LinkLabel linkLabelP3;
        private System.Windows.Forms.LinkLabel linkLabelP4;
        private System.Windows.Forms.LinkLabel linkLabelP5;
        private System.Windows.Forms.LinkLabel linkLabelP6;
        private System.Windows.Forms.LinkLabel linkLabelP7;
        private System.Windows.Forms.LinkLabel linkLabelP8;
        private System.Windows.Forms.LinkLabel linkLabelP9;
        private System.Windows.Forms.LinkLabel linkLabelP10;
        private System.Windows.Forms.LinkLabel linkLabelP11;
        private System.Windows.Forms.LinkLabel linkLabelP12;
        private System.Windows.Forms.LinkLabel linkLabelP13;
        private System.Windows.Forms.LinkLabel linkLabelP14;
        private System.Windows.Forms.LinkLabel linkLabelP1;
        private System.Windows.Forms.ListBox listBoxData;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelTeamName;
        private System.Windows.Forms.GroupBox groupBoxSort;
        private System.Windows.Forms.RadioButton radioButtonVo2max;
        private System.Windows.Forms.RadioButton radioButtonSpeed;
        private System.Windows.Forms.RadioButton radioButtonBMI;
        private System.Windows.Forms.RadioButton radioButtonHeartRate;
        private System.Windows.Forms.ListBox listBoxSchedule;
        private System.Windows.Forms.Label labelSchedule;
        private System.Windows.Forms.Button btnLogout;
    }
}