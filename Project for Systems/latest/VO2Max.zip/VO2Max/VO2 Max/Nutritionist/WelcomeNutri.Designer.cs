﻿namespace VO2_Max.Nutritionist
{
    partial class ViewDiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.tabControlBlood = new System.Windows.Forms.TabControl();
            this.tabPageO = new System.Windows.Forms.TabPage();
            this.tabControlO = new System.Windows.Forms.TabControl();
            this.tabPageOHealth = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.labelOAvoid = new System.Windows.Forms.Label();
            this.listBoxOAvoid = new System.Windows.Forms.ListBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labelONeut = new System.Windows.Forms.Label();
            this.listBoxONeut = new System.Windows.Forms.ListBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.labelOBen = new System.Windows.Forms.Label();
            this.listBoxOBen = new System.Windows.Forms.ListBox();
            this.tabPageOWeightGain = new System.Windows.Forms.TabPage();
            this.tabPageA = new System.Windows.Forms.TabPage();
            this.tabControlA = new System.Windows.Forms.TabControl();
            this.tabPageAHealth = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.listBoxAvo = new System.Windows.Forms.ListBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.listBoxNeu = new System.Windows.Forms.ListBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.listBoxBen = new System.Windows.Forms.ListBox();
            this.tabPageAWeightGain = new System.Windows.Forms.TabPage();
            this.listBoxGain = new System.Windows.Forms.ListBox();
            this.tabPageAB = new System.Windows.Forms.TabPage();
            this.tabPageB = new System.Windows.Forms.TabPage();
            this.labelName = new System.Windows.Forms.Label();
            this.tabPageAWeightLoss = new System.Windows.Forms.TabPage();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.tabPageOWeightLoss = new System.Windows.Forms.TabPage();
            this.listBoxOGain = new System.Windows.Forms.ListBox();
            this.listBoxOLoss = new System.Windows.Forms.ListBox();
            this.tabControlAB = new System.Windows.Forms.TabControl();
            this.tabPageABHealth = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.listBox8 = new System.Windows.Forms.ListBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.listBox9 = new System.Windows.Forms.ListBox();
            this.tabPageABWeightGain = new System.Windows.Forms.TabPage();
            this.listBox10 = new System.Windows.Forms.ListBox();
            this.tabPageABWeightLoss = new System.Windows.Forms.TabPage();
            this.listBox11 = new System.Windows.Forms.ListBox();
            this.tabControlB = new System.Windows.Forms.TabControl();
            this.tabPageBHealth = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.listBox12 = new System.Windows.Forms.ListBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.listBox13 = new System.Windows.Forms.ListBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.listBox14 = new System.Windows.Forms.ListBox();
            this.tabPageBWeightGain = new System.Windows.Forms.TabPage();
            this.listBox15 = new System.Windows.Forms.ListBox();
            this.tabPageWeightLoss = new System.Windows.Forms.TabPage();
            this.listBoxBLoss = new System.Windows.Forms.ListBox();
            this.tabControlBlood.SuspendLayout();
            this.tabPageO.SuspendLayout();
            this.tabControlO.SuspendLayout();
            this.tabPageOHealth.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabPageOWeightGain.SuspendLayout();
            this.tabPageA.SuspendLayout();
            this.tabControlA.SuspendLayout();
            this.tabPageAHealth.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tabPageAWeightGain.SuspendLayout();
            this.tabPageAB.SuspendLayout();
            this.tabPageB.SuspendLayout();
            this.tabPageAWeightLoss.SuspendLayout();
            this.tabPageOWeightLoss.SuspendLayout();
            this.tabControlAB.SuspendLayout();
            this.tabPageABHealth.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPageABWeightGain.SuspendLayout();
            this.tabPageABWeightLoss.SuspendLayout();
            this.tabControlB.SuspendLayout();
            this.tabPageBHealth.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tabPageBWeightGain.SuspendLayout();
            this.tabPageWeightLoss.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(799, 29);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(111, 38);
            this.btnBack.TabIndex = 0;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // tabControlBlood
            // 
            this.tabControlBlood.Controls.Add(this.tabPageO);
            this.tabControlBlood.Controls.Add(this.tabPageA);
            this.tabControlBlood.Controls.Add(this.tabPageAB);
            this.tabControlBlood.Controls.Add(this.tabPageB);
            this.tabControlBlood.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlBlood.Location = new System.Drawing.Point(1, 73);
            this.tabControlBlood.Multiline = true;
            this.tabControlBlood.Name = "tabControlBlood";
            this.tabControlBlood.SelectedIndex = 0;
            this.tabControlBlood.Size = new System.Drawing.Size(933, 496);
            this.tabControlBlood.TabIndex = 1;
            // 
            // tabPageO
            // 
            this.tabPageO.BackColor = System.Drawing.Color.LightGray;
            this.tabPageO.Controls.Add(this.tabControlO);
            this.tabPageO.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageO.Location = new System.Drawing.Point(4, 25);
            this.tabPageO.Name = "tabPageO";
            this.tabPageO.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageO.Size = new System.Drawing.Size(925, 467);
            this.tabPageO.TabIndex = 0;
            this.tabPageO.Text = "Blood Type O";
            // 
            // tabControlO
            // 
            this.tabControlO.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControlO.Controls.Add(this.tabPageOHealth);
            this.tabControlO.Controls.Add(this.tabPageOWeightGain);
            this.tabControlO.Controls.Add(this.tabPageOWeightLoss);
            this.tabControlO.Location = new System.Drawing.Point(33, 6);
            this.tabControlO.Multiline = true;
            this.tabControlO.Name = "tabControlO";
            this.tabControlO.SelectedIndex = 0;
            this.tabControlO.Size = new System.Drawing.Size(886, 460);
            this.tabControlO.TabIndex = 0;
            // 
            // tabPageOHealth
            // 
            this.tabPageOHealth.BackColor = System.Drawing.Color.DimGray;
            this.tabPageOHealth.Controls.Add(this.panel4);
            this.tabPageOHealth.Controls.Add(this.panel5);
            this.tabPageOHealth.Controls.Add(this.panel6);
            this.tabPageOHealth.Location = new System.Drawing.Point(28, 4);
            this.tabPageOHealth.Name = "tabPageOHealth";
            this.tabPageOHealth.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageOHealth.Size = new System.Drawing.Size(854, 452);
            this.tabPageOHealth.TabIndex = 0;
            this.tabPageOHealth.Text = "Health";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gray;
            this.panel4.Controls.Add(this.labelOAvoid);
            this.panel4.Controls.Add(this.listBoxOAvoid);
            this.panel4.Location = new System.Drawing.Point(572, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(279, 440);
            this.panel4.TabIndex = 5;
            // 
            // labelOAvoid
            // 
            this.labelOAvoid.AutoSize = true;
            this.labelOAvoid.BackColor = System.Drawing.Color.Transparent;
            this.labelOAvoid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOAvoid.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelOAvoid.Location = new System.Drawing.Point(12, 8);
            this.labelOAvoid.Name = "labelOAvoid";
            this.labelOAvoid.Size = new System.Drawing.Size(105, 16);
            this.labelOAvoid.TabIndex = 5;
            this.labelOAvoid.Text = "Food to Avoid";
            // 
            // listBoxOAvoid
            // 
            this.listBoxOAvoid.FormattingEnabled = true;
            this.listBoxOAvoid.ItemHeight = 20;
            this.listBoxOAvoid.Items.AddRange(new object[] {
            "META & POULTRY",
            "---------------------",
            "Pork",
            "Ham",
            "Bacon",
            "Goose",
            "",
            "SEAFOOD",
            "--------------------",
            "Sola",
            "Catfish",
            "Octopus",
            "Smoked salmon"});
            this.listBoxOAvoid.Location = new System.Drawing.Point(6, 27);
            this.listBoxOAvoid.Name = "listBoxOAvoid";
            this.listBoxOAvoid.Size = new System.Drawing.Size(265, 404);
            this.listBoxOAvoid.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gray;
            this.panel5.Controls.Add(this.labelONeut);
            this.panel5.Controls.Add(this.listBoxONeut);
            this.panel5.Location = new System.Drawing.Point(288, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(279, 440);
            this.panel5.TabIndex = 4;
            // 
            // labelONeut
            // 
            this.labelONeut.AutoSize = true;
            this.labelONeut.BackColor = System.Drawing.Color.Transparent;
            this.labelONeut.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelONeut.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelONeut.Location = new System.Drawing.Point(3, 8);
            this.labelONeut.Name = "labelONeut";
            this.labelONeut.Size = new System.Drawing.Size(98, 16);
            this.labelONeut.TabIndex = 5;
            this.labelONeut.Text = "Neutral Food";
            // 
            // listBoxONeut
            // 
            this.listBoxONeut.FormattingEnabled = true;
            this.listBoxONeut.ItemHeight = 20;
            this.listBoxONeut.Items.AddRange(new object[] {
            "MEAT & POULTRY",
            "----------------------",
            "Chicken",
            "Duck",
            "Quail",
            "Rabbit",
            "Turkey",
            "",
            "SEAFOOD",
            "-----------------------",
            "Abalone",
            "Tuna",
            "Carp",
            "Anchovy",
            "Clams",
            "Crab",
            "Crayfish",
            "Eals",
            "Frog legs",
            "Grouper",
            "Haddock",
            "Harring",
            "Lobster",
            "Mussels",
            "Oysters",
            "Prawns",
            "scallops",
            "Sea bass",
            "Sea trout",
            "Shark",
            "Squid"});
            this.listBoxONeut.Location = new System.Drawing.Point(11, 27);
            this.listBoxONeut.Name = "listBoxONeut";
            this.listBoxONeut.Size = new System.Drawing.Size(265, 404);
            this.listBoxONeut.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gray;
            this.panel6.Controls.Add(this.labelOBen);
            this.panel6.Controls.Add(this.listBoxOBen);
            this.panel6.Location = new System.Drawing.Point(3, 6);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(279, 440);
            this.panel6.TabIndex = 3;
            // 
            // labelOBen
            // 
            this.labelOBen.AutoSize = true;
            this.labelOBen.BackColor = System.Drawing.Color.Transparent;
            this.labelOBen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOBen.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelOBen.Location = new System.Drawing.Point(3, 8);
            this.labelOBen.Name = "labelOBen";
            this.labelOBen.Size = new System.Drawing.Size(152, 16);
            this.labelOBen.TabIndex = 5;
            this.labelOBen.Text = "High beneficial Food";
            // 
            // listBoxOBen
            // 
            this.listBoxOBen.FormattingEnabled = true;
            this.listBoxOBen.ItemHeight = 20;
            this.listBoxOBen.Items.AddRange(new object[] {
            "MEAT & POULTRY",
            "--------------------",
            "Beef",
            "Lamb",
            "Mutton",
            "Veal",
            "",
            "SEAFOOD",
            "-------------------",
            "Mackeral",
            "Snapper",
            "Cod",
            "Salmon",
            "Sardlines",
            "Swordfish"});
            this.listBoxOBen.Location = new System.Drawing.Point(6, 27);
            this.listBoxOBen.Name = "listBoxOBen";
            this.listBoxOBen.Size = new System.Drawing.Size(265, 404);
            this.listBoxOBen.TabIndex = 4;
            // 
            // tabPageOWeightGain
            // 
            this.tabPageOWeightGain.BackColor = System.Drawing.Color.DimGray;
            this.tabPageOWeightGain.Controls.Add(this.listBoxOGain);
            this.tabPageOWeightGain.Location = new System.Drawing.Point(28, 4);
            this.tabPageOWeightGain.Name = "tabPageOWeightGain";
            this.tabPageOWeightGain.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageOWeightGain.Size = new System.Drawing.Size(854, 452);
            this.tabPageOWeightGain.TabIndex = 1;
            this.tabPageOWeightGain.Text = "Weight Gain";
            // 
            // tabPageA
            // 
            this.tabPageA.Controls.Add(this.tabControlA);
            this.tabPageA.Location = new System.Drawing.Point(4, 25);
            this.tabPageA.Name = "tabPageA";
            this.tabPageA.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageA.Size = new System.Drawing.Size(925, 467);
            this.tabPageA.TabIndex = 1;
            this.tabPageA.Text = "Blood Type A";
            this.tabPageA.UseVisualStyleBackColor = true;
            // 
            // tabControlA
            // 
            this.tabControlA.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControlA.Controls.Add(this.tabPageAHealth);
            this.tabControlA.Controls.Add(this.tabPageAWeightGain);
            this.tabControlA.Controls.Add(this.tabPageAWeightLoss);
            this.tabControlA.Location = new System.Drawing.Point(19, 3);
            this.tabControlA.Multiline = true;
            this.tabControlA.Name = "tabControlA";
            this.tabControlA.SelectedIndex = 0;
            this.tabControlA.Size = new System.Drawing.Size(886, 460);
            this.tabControlA.TabIndex = 1;
            // 
            // tabPageAHealth
            // 
            this.tabPageAHealth.BackColor = System.Drawing.Color.DimGray;
            this.tabPageAHealth.Controls.Add(this.panel7);
            this.tabPageAHealth.Controls.Add(this.panel8);
            this.tabPageAHealth.Controls.Add(this.panel9);
            this.tabPageAHealth.Location = new System.Drawing.Point(25, 4);
            this.tabPageAHealth.Name = "tabPageAHealth";
            this.tabPageAHealth.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAHealth.Size = new System.Drawing.Size(857, 452);
            this.tabPageAHealth.TabIndex = 0;
            this.tabPageAHealth.Text = "Health";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gray;
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.listBoxAvo);
            this.panel7.Location = new System.Drawing.Point(573, 6);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(279, 440);
            this.panel7.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(12, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Food to Avoid";
            // 
            // listBoxAvo
            // 
            this.listBoxAvo.FormattingEnabled = true;
            this.listBoxAvo.ItemHeight = 16;
            this.listBoxAvo.Items.AddRange(new object[] {
            "META & POULTRY",
            "---------------------",
            "Beef",
            "Lamb",
            "Mutton",
            "Veal",
            "Pork",
            "Duck",
            "Quail",
            "Rabbit",
            "Ham",
            "Bacon",
            "Goose",
            "",
            "SEAFOOD",
            "--------------------",
            "Anchovy",
            "Clams",
            "Crab",
            "Crayfish",
            "Eals",
            "Frog legs",
            "Haddock",
            "Herring",
            "Lobster",
            "Mussels",
            "Oysters",
            "Prawn",
            "Scallops",
            "Sole",
            "Squid",
            "Catfish",
            "Octopus",
            "Smoked Salmon"});
            this.listBoxAvo.Location = new System.Drawing.Point(6, 27);
            this.listBoxAvo.Name = "listBoxAvo";
            this.listBoxAvo.Size = new System.Drawing.Size(265, 404);
            this.listBoxAvo.TabIndex = 4;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Gray;
            this.panel8.Controls.Add(this.label6);
            this.panel8.Controls.Add(this.listBoxNeu);
            this.panel8.Location = new System.Drawing.Point(289, 6);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(279, 440);
            this.panel8.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(3, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Neutral Food";
            // 
            // listBoxNeu
            // 
            this.listBoxNeu.FormattingEnabled = true;
            this.listBoxNeu.ItemHeight = 16;
            this.listBoxNeu.Items.AddRange(new object[] {
            "MEAT & POULTRY",
            "----------------------",
            "Chicken",
            "Turkey",
            "",
            "SEAFOOD",
            "-----------------------",
            "Snapper",
            "Swordfish",
            "Abalone",
            "Tuna",
            "Sea bass",
            "Shark"});
            this.listBoxNeu.Location = new System.Drawing.Point(6, 27);
            this.listBoxNeu.Name = "listBoxNeu";
            this.listBoxNeu.Size = new System.Drawing.Size(265, 404);
            this.listBoxNeu.TabIndex = 4;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gray;
            this.panel9.Controls.Add(this.label7);
            this.panel9.Controls.Add(this.listBoxBen);
            this.panel9.Location = new System.Drawing.Point(4, 6);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(279, 440);
            this.panel9.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(3, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 16);
            this.label7.TabIndex = 5;
            this.label7.Text = "High beneficial Food";
            // 
            // listBoxBen
            // 
            this.listBoxBen.FormattingEnabled = true;
            this.listBoxBen.ItemHeight = 16;
            this.listBoxBen.Items.AddRange(new object[] {
            "SEAFOOD",
            "-------------------",
            "Cod",
            "Mackeral",
            "Salmon",
            "Sardlines",
            "Red Snapper",
            "Carp",
            "Grouper",
            "Sea Trout"});
            this.listBoxBen.Location = new System.Drawing.Point(6, 27);
            this.listBoxBen.Name = "listBoxBen";
            this.listBoxBen.Size = new System.Drawing.Size(265, 404);
            this.listBoxBen.TabIndex = 4;
            // 
            // tabPageAWeightGain
            // 
            this.tabPageAWeightGain.BackColor = System.Drawing.Color.DimGray;
            this.tabPageAWeightGain.Controls.Add(this.listBoxGain);
            this.tabPageAWeightGain.Location = new System.Drawing.Point(25, 4);
            this.tabPageAWeightGain.Name = "tabPageAWeightGain";
            this.tabPageAWeightGain.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAWeightGain.Size = new System.Drawing.Size(857, 452);
            this.tabPageAWeightGain.TabIndex = 1;
            this.tabPageAWeightGain.Text = "Weight Gain";
            // 
            // listBoxGain
            // 
            this.listBoxGain.FormattingEnabled = true;
            this.listBoxGain.ItemHeight = 16;
            this.listBoxGain.Items.AddRange(new object[] {
            "Red meat",
            "Milk",
            "Yoghurt",
            "Beans",
            "Cereal",
            "Bread"});
            this.listBoxGain.Location = new System.Drawing.Point(6, 4);
            this.listBoxGain.Name = "listBoxGain";
            this.listBoxGain.Size = new System.Drawing.Size(845, 436);
            this.listBoxGain.TabIndex = 0;
            // 
            // tabPageAB
            // 
            this.tabPageAB.Controls.Add(this.tabControlAB);
            this.tabPageAB.Location = new System.Drawing.Point(4, 25);
            this.tabPageAB.Name = "tabPageAB";
            this.tabPageAB.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAB.Size = new System.Drawing.Size(925, 467);
            this.tabPageAB.TabIndex = 2;
            this.tabPageAB.Text = "Blood Type AB";
            this.tabPageAB.UseVisualStyleBackColor = true;
            // 
            // tabPageB
            // 
            this.tabPageB.Controls.Add(this.tabControlB);
            this.tabPageB.Location = new System.Drawing.Point(4, 25);
            this.tabPageB.Name = "tabPageB";
            this.tabPageB.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageB.Size = new System.Drawing.Size(925, 467);
            this.tabPageB.TabIndex = 3;
            this.tabPageB.Text = "Blood Type B";
            this.tabPageB.UseVisualStyleBackColor = true;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(35, 40);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(130, 16);
            this.labelName.TabIndex = 2;
            this.labelName.Text = "Nutritionist Name ";
            // 
            // tabPageAWeightLoss
            // 
            this.tabPageAWeightLoss.Controls.Add(this.listBox7);
            this.tabPageAWeightLoss.Location = new System.Drawing.Point(25, 4);
            this.tabPageAWeightLoss.Name = "tabPageAWeightLoss";
            this.tabPageAWeightLoss.Size = new System.Drawing.Size(857, 452);
            this.tabPageAWeightLoss.TabIndex = 2;
            this.tabPageAWeightLoss.Text = "WeightLoss";
            this.tabPageAWeightLoss.UseVisualStyleBackColor = true;
            // 
            // listBox7
            // 
            this.listBox7.FormattingEnabled = true;
            this.listBox7.ItemHeight = 16;
            this.listBox7.Items.AddRange(new object[] {
            "Pineapple",
            "Pumkin",
            "Cabbage",
            "Potato",
            "Carraot",
            "Onion",
            "Beat root",
            "Sweet potato",
            "Beans"});
            this.listBox7.Location = new System.Drawing.Point(6, 8);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(845, 436);
            this.listBox7.TabIndex = 1;
            // 
            // tabPageOWeightLoss
            // 
            this.tabPageOWeightLoss.Controls.Add(this.listBoxOLoss);
            this.tabPageOWeightLoss.Location = new System.Drawing.Point(28, 4);
            this.tabPageOWeightLoss.Name = "tabPageOWeightLoss";
            this.tabPageOWeightLoss.Size = new System.Drawing.Size(854, 452);
            this.tabPageOWeightLoss.TabIndex = 2;
            this.tabPageOWeightLoss.Text = "Weight Loss";
            this.tabPageOWeightLoss.UseVisualStyleBackColor = true;
            // 
            // listBoxOGain
            // 
            this.listBoxOGain.FormattingEnabled = true;
            this.listBoxOGain.ItemHeight = 20;
            this.listBoxOGain.Items.AddRange(new object[] {
            "Beans",
            "Sugar",
            "Sweet Corn",
            "Cabbage",
            "Mustard",
            "Lentils",
            "Bread",
            "Cereal"});
            this.listBoxOGain.Location = new System.Drawing.Point(5, 14);
            this.listBoxOGain.Name = "listBoxOGain";
            this.listBoxOGain.Size = new System.Drawing.Size(845, 424);
            this.listBoxOGain.TabIndex = 2;
            // 
            // listBoxOLoss
            // 
            this.listBoxOLoss.FormattingEnabled = true;
            this.listBoxOLoss.ItemHeight = 20;
            this.listBoxOLoss.Items.AddRange(new object[] {
            "Kelp",
            "Red meat",
            "White meat",
            "Seafood",
            "Liver",
            "Broccoli"});
            this.listBoxOLoss.Location = new System.Drawing.Point(5, 14);
            this.listBoxOLoss.Name = "listBoxOLoss";
            this.listBoxOLoss.Size = new System.Drawing.Size(845, 424);
            this.listBoxOLoss.TabIndex = 2;
            // 
            // tabControlAB
            // 
            this.tabControlAB.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControlAB.Controls.Add(this.tabPageABHealth);
            this.tabControlAB.Controls.Add(this.tabPageABWeightGain);
            this.tabControlAB.Controls.Add(this.tabPageABWeightLoss);
            this.tabControlAB.Location = new System.Drawing.Point(19, 3);
            this.tabControlAB.Multiline = true;
            this.tabControlAB.Name = "tabControlAB";
            this.tabControlAB.SelectedIndex = 0;
            this.tabControlAB.Size = new System.Drawing.Size(886, 460);
            this.tabControlAB.TabIndex = 1;
            // 
            // tabPageABHealth
            // 
            this.tabPageABHealth.BackColor = System.Drawing.Color.DimGray;
            this.tabPageABHealth.Controls.Add(this.panel1);
            this.tabPageABHealth.Controls.Add(this.panel2);
            this.tabPageABHealth.Controls.Add(this.panel3);
            this.tabPageABHealth.Location = new System.Drawing.Point(25, 4);
            this.tabPageABHealth.Name = "tabPageABHealth";
            this.tabPageABHealth.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageABHealth.Size = new System.Drawing.Size(857, 452);
            this.tabPageABHealth.TabIndex = 0;
            this.tabPageABHealth.Text = "Health";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.listBox3);
            this.panel1.Location = new System.Drawing.Point(572, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(279, 440);
            this.panel1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(12, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Food to Avoid";
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 16;
            this.listBox3.Items.AddRange(new object[] {
            "META & POULTRY",
            "---------------------",
            "Heart",
            "Partridge",
            "Pork",
            "Quail",
            "Veal",
            "Venison",
            "",
            "SEAFOOD",
            "--------------------",
            "Anchovy",
            "Beluga",
            "Barracuda",
            "Clam",
            "Crab",
            "Crayfish",
            "Lox",
            "Octopus",
            "Sea bass",
            "Sea trout",
            "Shrimp",
            "",
            "SPICE",
            "---------------------",
            "Almond extract",
            "Anisa",
            "Capers",
            "Corn syrup",
            "Pepper",
            "Tapioca",
            "Vinegar",
            "Tapioca",
            "",
            "BEVERAGES",
            "-------------------",
            "Coffee",
            "Soda cola",
            "Black tea",
            "Other Soda"});
            this.listBox3.Location = new System.Drawing.Point(6, 27);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(265, 404);
            this.listBox3.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.listBox8);
            this.panel2.Location = new System.Drawing.Point(288, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(279, 440);
            this.panel2.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(3, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Neutral Food";
            // 
            // listBox8
            // 
            this.listBox8.FormattingEnabled = true;
            this.listBox8.ItemHeight = 16;
            this.listBox8.Items.AddRange(new object[] {
            "MEAT & POULTRY",
            "----------------------",
            "Lamb",
            "Liver",
            "Mutton",
            "Pheasant",
            "Rabbit",
            "",
            "SEAFOOD",
            "-----------------------",
            "Abalone",
            "Bluefish",
            "Carp",
            "Catfish",
            "Cavior",
            "Mussels",
            "Smelt",
            "Squid",
            "Tilefish",
            "Whitefish",
            "",
            "SPICES",
            "-----------------------",
            "Cinnamon",
            "Nutmeg",
            "Soy sauce",
            "Wintergreen",
            "",
            "BEVERAGES",
            "-----------------------",
            "Beer",
            "Seltzer water",
            "Soda club",
            "Red wine",
            "White wine"});
            this.listBox8.Location = new System.Drawing.Point(6, 27);
            this.listBox8.Name = "listBox8";
            this.listBox8.Size = new System.Drawing.Size(265, 404);
            this.listBox8.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gray;
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.listBox9);
            this.panel3.Location = new System.Drawing.Point(3, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(279, 440);
            this.panel3.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(3, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 16);
            this.label9.TabIndex = 5;
            this.label9.Text = "High beneficial Food";
            // 
            // listBox9
            // 
            this.listBox9.FormattingEnabled = true;
            this.listBox9.ItemHeight = 16;
            this.listBox9.Items.AddRange(new object[] {
            "MEAT & POULTRY",
            "--------------------",
            "Turkey",
            "",
            "SEAFOOD",
            "-------------------",
            "Cod",
            "Grouper",
            "Mackerel",
            "Mahi Mahi",
            "Monkfish",
            "Pickerel",
            "Pike",
            "Porgy",
            "Salmon",
            "",
            "SPICES",
            "--------------------",
            "Miso",
            "",
            "BEVERAGES",
            "--------------------",
            "Green Tea"});
            this.listBox9.Location = new System.Drawing.Point(6, 27);
            this.listBox9.Name = "listBox9";
            this.listBox9.Size = new System.Drawing.Size(265, 404);
            this.listBox9.TabIndex = 4;
            // 
            // tabPageABWeightGain
            // 
            this.tabPageABWeightGain.BackColor = System.Drawing.Color.DimGray;
            this.tabPageABWeightGain.Controls.Add(this.listBox10);
            this.tabPageABWeightGain.Location = new System.Drawing.Point(25, 4);
            this.tabPageABWeightGain.Name = "tabPageABWeightGain";
            this.tabPageABWeightGain.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageABWeightGain.Size = new System.Drawing.Size(857, 452);
            this.tabPageABWeightGain.TabIndex = 1;
            this.tabPageABWeightGain.Text = "Weight Gain";
            // 
            // listBox10
            // 
            this.listBox10.FormattingEnabled = true;
            this.listBox10.ItemHeight = 16;
            this.listBox10.Items.AddRange(new object[] {
            "Sweet corn",
            "Lentils",
            "Peanuts",
            "Sesame seed",
            "Wheat"});
            this.listBox10.Location = new System.Drawing.Point(5, 14);
            this.listBox10.Name = "listBox10";
            this.listBox10.Size = new System.Drawing.Size(845, 420);
            this.listBox10.TabIndex = 2;
            // 
            // tabPageABWeightLoss
            // 
            this.tabPageABWeightLoss.Controls.Add(this.listBox11);
            this.tabPageABWeightLoss.Location = new System.Drawing.Point(25, 4);
            this.tabPageABWeightLoss.Name = "tabPageABWeightLoss";
            this.tabPageABWeightLoss.Size = new System.Drawing.Size(857, 452);
            this.tabPageABWeightLoss.TabIndex = 2;
            this.tabPageABWeightLoss.Text = "Weight Loss";
            this.tabPageABWeightLoss.UseVisualStyleBackColor = true;
            // 
            // listBox11
            // 
            this.listBox11.FormattingEnabled = true;
            this.listBox11.ItemHeight = 16;
            this.listBox11.Items.AddRange(new object[] {
            "Greeb vegetables",
            "White wheat",
            "Eggs",
            "Liver",
            "Liquorice tea"});
            this.listBox11.Location = new System.Drawing.Point(5, 14);
            this.listBox11.Name = "listBox11";
            this.listBox11.Size = new System.Drawing.Size(845, 420);
            this.listBox11.TabIndex = 2;
            // 
            // tabControlB
            // 
            this.tabControlB.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControlB.Controls.Add(this.tabPageBHealth);
            this.tabControlB.Controls.Add(this.tabPageBWeightGain);
            this.tabControlB.Controls.Add(this.tabPageWeightLoss);
            this.tabControlB.Location = new System.Drawing.Point(19, 3);
            this.tabControlB.Multiline = true;
            this.tabControlB.Name = "tabControlB";
            this.tabControlB.SelectedIndex = 0;
            this.tabControlB.Size = new System.Drawing.Size(886, 460);
            this.tabControlB.TabIndex = 1;
            // 
            // tabPageBHealth
            // 
            this.tabPageBHealth.BackColor = System.Drawing.Color.DimGray;
            this.tabPageBHealth.Controls.Add(this.panel10);
            this.tabPageBHealth.Controls.Add(this.panel11);
            this.tabPageBHealth.Controls.Add(this.panel12);
            this.tabPageBHealth.Location = new System.Drawing.Point(25, 4);
            this.tabPageBHealth.Name = "tabPageBHealth";
            this.tabPageBHealth.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBHealth.Size = new System.Drawing.Size(857, 452);
            this.tabPageBHealth.TabIndex = 0;
            this.tabPageBHealth.Text = "Health";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Gray;
            this.panel10.Controls.Add(this.label10);
            this.panel10.Controls.Add(this.listBox12);
            this.panel10.Location = new System.Drawing.Point(572, 6);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(279, 440);
            this.panel10.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(12, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 16);
            this.label10.TabIndex = 5;
            this.label10.Text = "Food to Avoid";
            // 
            // listBox12
            // 
            this.listBox12.FormattingEnabled = true;
            this.listBox12.ItemHeight = 16;
            this.listBox12.Items.AddRange(new object[] {
            "META & POULTRY",
            "---------------------",
            "Pork",
            "Ham",
            "Bacon",
            "Goose",
            "",
            "SEAFOOD",
            "--------------------",
            "Sola",
            "Catfish",
            "Octopus",
            "Smoked salmon"});
            this.listBox12.Location = new System.Drawing.Point(6, 27);
            this.listBox12.Name = "listBox12";
            this.listBox12.Size = new System.Drawing.Size(265, 404);
            this.listBox12.TabIndex = 4;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Gray;
            this.panel11.Controls.Add(this.label11);
            this.panel11.Controls.Add(this.listBox13);
            this.panel11.Location = new System.Drawing.Point(288, 6);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(279, 440);
            this.panel11.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(3, 8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 16);
            this.label11.TabIndex = 5;
            this.label11.Text = "Neutral Food";
            // 
            // listBox13
            // 
            this.listBox13.FormattingEnabled = true;
            this.listBox13.ItemHeight = 16;
            this.listBox13.Items.AddRange(new object[] {
            "MEAT & POULTRY",
            "----------------------",
            "Chicken",
            "Duck",
            "Quail",
            "Rabbit",
            "Turkey",
            "",
            "SEAFOOD",
            "-----------------------",
            "Abalone",
            "Tuna",
            "Carp",
            "Anchovy",
            "Clams",
            "Crab",
            "Crayfish",
            "Eals",
            "Frog legs",
            "Grouper",
            "Haddock",
            "Harring",
            "Lobster",
            "Mussels",
            "Oysters",
            "Prawns",
            "scallops",
            "Sea bass",
            "Sea trout",
            "Shark",
            "Squid"});
            this.listBox13.Location = new System.Drawing.Point(6, 27);
            this.listBox13.Name = "listBox13";
            this.listBox13.Size = new System.Drawing.Size(265, 404);
            this.listBox13.TabIndex = 4;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Gray;
            this.panel12.Controls.Add(this.label12);
            this.panel12.Controls.Add(this.listBox14);
            this.panel12.Location = new System.Drawing.Point(3, 6);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(279, 440);
            this.panel12.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(3, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(152, 16);
            this.label12.TabIndex = 5;
            this.label12.Text = "High beneficial Food";
            // 
            // listBox14
            // 
            this.listBox14.FormattingEnabled = true;
            this.listBox14.ItemHeight = 16;
            this.listBox14.Items.AddRange(new object[] {
            "META & POULTRY",
            "---------------------",
            "Lamb",
            "Mutton",
            "Rabbit",
            "Venison",
            "",
            "SEAFOOD",
            "--------------------",
            "Caviar",
            "Flounder",
            "Grouper",
            "",
            "SPICE",
            "---------------------",
            "",
            "",
            "BEVERAGES",
            "--------------------"});
            this.listBox14.Location = new System.Drawing.Point(6, 27);
            this.listBox14.Name = "listBox14";
            this.listBox14.Size = new System.Drawing.Size(265, 404);
            this.listBox14.TabIndex = 4;
            // 
            // tabPageBWeightGain
            // 
            this.tabPageBWeightGain.BackColor = System.Drawing.Color.DimGray;
            this.tabPageBWeightGain.Controls.Add(this.listBox15);
            this.tabPageBWeightGain.Location = new System.Drawing.Point(25, 4);
            this.tabPageBWeightGain.Name = "tabPageBWeightGain";
            this.tabPageBWeightGain.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBWeightGain.Size = new System.Drawing.Size(857, 452);
            this.tabPageBWeightGain.TabIndex = 1;
            this.tabPageBWeightGain.Text = "Weight Gain";
            // 
            // listBox15
            // 
            this.listBox15.FormattingEnabled = true;
            this.listBox15.ItemHeight = 16;
            this.listBox15.Items.AddRange(new object[] {
            "Sweet corn ",
            "Lentils",
            "Sesame seed",
            "Wheat"});
            this.listBox15.Location = new System.Drawing.Point(5, 14);
            this.listBox15.Name = "listBox15";
            this.listBox15.Size = new System.Drawing.Size(845, 420);
            this.listBox15.TabIndex = 2;
            // 
            // tabPageWeightLoss
            // 
            this.tabPageWeightLoss.Controls.Add(this.listBoxBLoss);
            this.tabPageWeightLoss.Location = new System.Drawing.Point(25, 4);
            this.tabPageWeightLoss.Name = "tabPageWeightLoss";
            this.tabPageWeightLoss.Size = new System.Drawing.Size(857, 452);
            this.tabPageWeightLoss.TabIndex = 2;
            this.tabPageWeightLoss.Text = "Weight Loss";
            this.tabPageWeightLoss.UseVisualStyleBackColor = true;
            // 
            // listBoxBLoss
            // 
            this.listBoxBLoss.FormattingEnabled = true;
            this.listBoxBLoss.ItemHeight = 16;
            this.listBoxBLoss.Items.AddRange(new object[] {
            "Green Vegetables",
            "Meat",
            "Eggs",
            "Liver",
            "Liquorice Tea"});
            this.listBoxBLoss.Location = new System.Drawing.Point(5, 14);
            this.listBoxBLoss.Name = "listBoxBLoss";
            this.listBoxBLoss.Size = new System.Drawing.Size(845, 420);
            this.listBoxBLoss.TabIndex = 2;
            // 
            // ViewDiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(967, 581);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.tabControlBlood);
            this.Controls.Add(this.btnBack);
            this.Name = "ViewDiet";
            this.Text = "ViewDiet";
            this.Load += new System.EventHandler(this.ViewDiet_Load);
            this.tabControlBlood.ResumeLayout(false);
            this.tabPageO.ResumeLayout(false);
            this.tabControlO.ResumeLayout(false);
            this.tabPageOHealth.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPageOWeightGain.ResumeLayout(false);
            this.tabPageA.ResumeLayout(false);
            this.tabControlA.ResumeLayout(false);
            this.tabPageAHealth.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.tabPageAWeightGain.ResumeLayout(false);
            this.tabPageAB.ResumeLayout(false);
            this.tabPageB.ResumeLayout(false);
            this.tabPageAWeightLoss.ResumeLayout(false);
            this.tabPageOWeightLoss.ResumeLayout(false);
            this.tabControlAB.ResumeLayout(false);
            this.tabPageABHealth.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPageABWeightGain.ResumeLayout(false);
            this.tabPageABWeightLoss.ResumeLayout(false);
            this.tabControlB.ResumeLayout(false);
            this.tabPageBHealth.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.tabPageBWeightGain.ResumeLayout(false);
            this.tabPageWeightLoss.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TabControl tabControlBlood;
        private System.Windows.Forms.TabPage tabPageO;
        private System.Windows.Forms.TabPage tabPageA;
        private System.Windows.Forms.TabControl tabControlO;
        private System.Windows.Forms.TabPage tabPageOHealth;
        private System.Windows.Forms.TabPage tabPageOWeightGain;
        private System.Windows.Forms.TabPage tabPageAB;
        private System.Windows.Forms.TabPage tabPageB;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TabControl tabControlA;
        private System.Windows.Forms.TabPage tabPageAHealth;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listBoxAvo;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBoxNeu;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox listBoxBen;
        private System.Windows.Forms.TabPage tabPageAWeightGain;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label labelOAvoid;
        private System.Windows.Forms.ListBox listBoxOAvoid;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label labelONeut;
        private System.Windows.Forms.ListBox listBoxONeut;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label labelOBen;
        private System.Windows.Forms.ListBox listBoxOBen;
        private System.Windows.Forms.ListBox listBoxGain;
        private System.Windows.Forms.TabPage tabPageAWeightLoss;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.ListBox listBoxOGain;
        private System.Windows.Forms.TabPage tabPageOWeightLoss;
        private System.Windows.Forms.ListBox listBoxOLoss;
        private System.Windows.Forms.TabControl tabControlAB;
        private System.Windows.Forms.TabPage tabPageABHealth;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox listBox8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox listBox9;
        private System.Windows.Forms.TabPage tabPageABWeightGain;
        private System.Windows.Forms.ListBox listBox10;
        private System.Windows.Forms.TabPage tabPageABWeightLoss;
        private System.Windows.Forms.ListBox listBox11;
        private System.Windows.Forms.TabControl tabControlB;
        private System.Windows.Forms.TabPage tabPageBHealth;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox listBox12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ListBox listBox13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox listBox14;
        private System.Windows.Forms.TabPage tabPageBWeightGain;
        private System.Windows.Forms.ListBox listBox15;
        private System.Windows.Forms.TabPage tabPageWeightLoss;
        private System.Windows.Forms.ListBox listBoxBLoss;
    }
}